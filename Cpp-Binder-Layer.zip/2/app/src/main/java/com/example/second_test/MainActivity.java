package com.example.second_test;

import android.os.Bundle;

import android.os.Looper;
import android.os.Handler;
import android.util.Log; // Import the Log class

import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.second_test.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    // Used to load the 'first_test' library on application startup.
    static {
        System.loadLibrary("second_test");
    }
    private ActivityMainBinding binding;

    private Handler handler = new Handler(Looper.getMainLooper());



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Example of a call to a native method
        TextView tv = binding.sampleText;
        // tv.setText(stringFromJNI());

        // Update the UI with received data
        updateUI();

        // Start data reception in the background
        startReceivingDataInBackground();

    }


    private void updateUI() {
        Log.d("MainActivity", "updateUI() is called"); // Add this log statement

        // Get the latest frame data from the native side
        FirstFrameData data = getFrame1Data(); // Call the native method to get the latest data

        // Get the motor speed and other parameters from the updated data
        int speed = data.getMotorSpeedDec();
        int dcBusCurrent = data.getDcBusCurrentAmps();
        int motorPhaseCurrent = data.getMotorPhaseCurrentAmps();


        // Update the UI with the new parameters and frame identifier
        String text = "Frame 0x100 Data Received:\n\n\n" +
                      "Motor Speed: " + speed + "\n" +
                      "DC Bus Current: " + dcBusCurrent + "\n" +
                      "Motor Phase Current: " + motorPhaseCurrent + "\n";


        // Update the UI with the motor speed
        handler.post(() -> {
            TextView tv = binding.sampleText;
            tv.setText(text);
        });

        // Schedule next UI update after a delay (100 milliseconds)
        handler.postDelayed(this::updateUI, 100);
    }


    // Helper method to start data reception in a separate thread
    private void startReceivingDataInBackground() {
        new Thread(() -> {
            startReceivingData();

            // The data reception will continue in the background thread until stopReceivingData is called
            // You may also want to handle the stop condition or error scenarios here
        }).start();
    }

    public static native FirstFrameData getFrame1Data();
    public static native SecondFrameData getFrame2Data();

    public static native void startReceivingData();
    public static native void stopReceivingData();

    @Override
    protected void onDestroy() {
        // Stop receiving data when the activity is destroyed
        stopReceivingData();

        super.onDestroy();
    }

}